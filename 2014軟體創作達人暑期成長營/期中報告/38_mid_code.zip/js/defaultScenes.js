/**
 *This is a JS code to change screen light by detecting ambient light.
 */
function Auto_ScreenLight(ambient_event) {
    if (ambient_event.value < 9) {
        SetScreenAutoBrightness(true);
    }
}

/*
 * This is a JS code to limit phone call when speed exceed 20 km/h.
 */
function SpeedShow(position) {
    var speed = position.coords.speed;
    //var speed = 40; //fake speed
    if (speed > 5.55555556) {
        SetPhoneCallLimited(true);
    } else {
        SetPhoneCallLimited(false);
    }
}

function showError(error) {
    switch (error.code) {
        case error.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
        case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
        case error.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
            break;
    }
}

function Auto_SpeedLimited() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(SpeedShow, showError);
    } else {
        alert("Something is Error on geolocation.");
    }
}

/*
    sleep mode
    Precodition: input a boolean parameter to control off or on
    Postcodition: turn on powersaving mode to avoid power down after sleeping
                    and set all sound quietly
 */
function sleepMode(check) {
    if (check) {
        setPowerSaving(check);
        setSound(0);
        alert("Sleep Mode has started.");
    } else {
        setPowerSaving(check);
        alert("Sleep Mode has stopped.");
    }
}
